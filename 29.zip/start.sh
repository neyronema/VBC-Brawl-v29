#!/bin/bash
while true
do
    python3.7 start.py
    sleep 1
done
