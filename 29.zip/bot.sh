#!/bin/bash
while true
do
    python3.7 bot.py
    sleep 1
done
